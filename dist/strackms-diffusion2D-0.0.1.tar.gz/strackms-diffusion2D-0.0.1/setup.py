from setuptools import setup
import setuptools

if __name__ == "__main__":
  setup()